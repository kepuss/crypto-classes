package com.rsa;

import java.math.BigInteger;
import java.util.concurrent.*;

/**
 * Created by kepuss on 25.04.15.
 */
public class CTR {

    public static BigInteger getCTR(BigInteger[] dps , BigInteger[] p, BigInteger c, BigInteger N, BigInteger[] e,int threads) throws ExecutionException, InterruptedException {
    //    BigInteger[]y = new BigInteger[p.length];
//        y[0]=BigInteger.valueOf(2);
//        y[1]=BigInteger.valueOf(3);
//        y[2]=BigInteger.valueOf(1);
 //       BigInteger[]e = new BigInteger[p.length];
        BigInteger sum = BigInteger.ZERO;
//        for(int i =0;i<p.length;i++){
//            y[i]= c.modPow(dps[i],p[i]);
//            e[i]= calculateE(p[i], N);
//            sum = sum.add(y[i].multiply(e[i]));
//        }

        ExecutorService executor = Executors.newFixedThreadPool(threads);
        Callable<BigInteger>[] callTab = new Callable[p.length];
        Future<BigInteger>[] futureTab = new Future[p.length];
        long startTime = System.nanoTime();
        for(int i =0;i<p.length;i++){
            callTab[i] = new CRTthread(dps[i],p[i],c,e[i]);
            futureTab[i] = executor.submit(callTab[i]);
        }

        for(int i =0;i<p.length;i++) {
            sum = sum.add(futureTab[i].get());
        }
        long endTime = System.nanoTime();
        System.out.println( "mean time: "+(endTime - startTime));
        executor.shutdown();
        return sum.mod(N);

    }

    private static  BigInteger calculateE(BigInteger n, BigInteger N){
        int[] values = EEA.getEEA(n.intValue(),N.divide(n).intValue());
        BigInteger sel = BigInteger.valueOf(values[1]);
        sel = sel.multiply(N.divide(n));
        return sel;
    }
}
